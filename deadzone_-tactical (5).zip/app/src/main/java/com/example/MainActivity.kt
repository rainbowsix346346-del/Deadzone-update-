package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.GameViewModel
import com.example.ui.Screen
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.SoundManager

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SoundManager.init(applicationContext)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: GameViewModel = viewModel()
                val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
                val selectedLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()
                val difficulty by viewModel.difficulty.collectAsStateWithLifecycle()
                val sensitivity by viewModel.controlSensitivity.collectAsStateWithLifecycle()
                val musicVolume by viewModel.musicVolume.collectAsStateWithLifecycle()
                val sfxVolume by viewModel.sfxVolume.collectAsStateWithLifecycle()
                val playerProfile by viewModel.playerProfile.collectAsStateWithLifecycle()
                val topScores by viewModel.topScores.collectAsStateWithLifecycle()
                val gameState by viewModel.gameState.collectAsStateWithLifecycle()

                LaunchedEffect(currentScreen) {
                    if (currentScreen == Screen.GAME) {
                        SoundManager.playMusic(R.raw.music_gameplay)
                    } else {
                        SoundManager.playMusic(R.raw.music_lobby)
                    }
                }

                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    // innerPadding is ignored for full immersive gameplay layouts
                    _unused(innerPadding)
                    
                    when (currentScreen) {
                        Screen.SPLASH -> {
                            SplashScreen(
                                language = selectedLanguage,
                                onNavigateToMenu = { viewModel.navigateTo(Screen.MENU) }
                            )
                        }
                        Screen.MENU -> {
                            MenuScreen(
                                language = selectedLanguage,
                                onNavigate = { viewModel.navigateTo(it) },
                                onStartGame = { viewModel.navigateTo(Screen.LEVEL_SELECT) }
                            )
                        }
                        Screen.LEVEL_SELECT -> {
                            LevelSelectScreen(
                                language = selectedLanguage,
                                onBack = { viewModel.navigateTo(Screen.MENU) },
                                onSelectLevel = { levelId ->
                                    viewModel.startNewGame()
                                }
                            )
                        }
                        Screen.LOBBY -> {
                            LobbyScreen(
                                profile = playerProfile,
                                language = selectedLanguage,
                                onBack = { viewModel.navigateTo(Screen.MENU) },
                                onEquipSkin = { viewModel.equipSkin(it) },
                                onBuySkin = { name, cost -> viewModel.buySkin(name, cost) },
                                onUpgradeSkill = { type, cost -> viewModel.upgradeSkill(type, cost) },
                                onUpdateIgn = { newName -> viewModel.updateIgn(newName) }
                            )
                        }
                        Screen.SETTINGS -> {
                            SettingsScreen(
                                currentLanguage = selectedLanguage,
                                currentDifficulty = difficulty,
                                currentSensitivity = sensitivity,
                                musicVolume = musicVolume,
                                sfxVolume = sfxVolume,
                                onBack = { viewModel.navigateTo(Screen.MENU) },
                                onLanguageChange = { viewModel.setLanguage(it) },
                                onDifficultyChange = { viewModel.setDifficulty(it) },
                                onSensitivityChange = { viewModel.setSensitivity(it) },
                                onMusicVolumeChange = { viewModel.setMusicVolume(it) },
                                onSfxVolumeChange = { viewModel.setSfxVolume(it) }
                            )
                        }
                        Screen.LEADERBOARD -> {
                            LeaderboardScreen(
                                topScores = topScores,
                                language = selectedLanguage,
                                onBack = { viewModel.navigateTo(Screen.MENU) },
                                onReportCheat = { id -> viewModel.reportCheating(id) }
                            )
                        }
                        Screen.IAP -> {
                            IapScreen(
                                language = selectedLanguage,
                                onBack = { viewModel.navigateTo(Screen.MENU) },
                                onPurchaseFinished = { amount -> viewModel.triggerInAppPurchase(amount) }
                            )
                        }
                        Screen.GAME -> {
                            GameScreen(
                                session = gameState,
                                language = selectedLanguage,
                                sensitivity = sensitivity,
                                onBackToLobby = { viewModel.navigateTo(Screen.MENU) },
                                onGameResult = { kills, score, cashEarned ->
                                    viewModel.submitGameResult(kills, score, cashEarned)
                                },
                                onPlayAgain = {
                                    viewModel.navigateTo(Screen.LEVEL_SELECT)
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onPause() {
        super.onPause()
        SoundManager.pauseMusic()
    }

    override fun onResume() {
        super.onResume()
        SoundManager.resumeMusic()
    }
}

// Suppress unused content warnings cleanly
private fun _unused(any: Any) {}
