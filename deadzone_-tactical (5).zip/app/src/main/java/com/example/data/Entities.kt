package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "player_profile")
data class PlayerProfile(
    @PrimaryKey val uid: Long,
    val ign: String,
    val gamesPlayed: Int = 0,
    val totalKills: Int = 0,
    val highScore: Int = 0,
    val cash: Int = 1000,
    val selectedSkin: String = "Stealth Recon",
    val unlockedSkins: String = "Stealth Recon", // comma-separated
    val reloadSkillLevel: Int = 0,    // 0 to 5
    val stealthSkillLevel: Int = 0,   // 0 to 5
    val batterySkillLevel: Int = 0    // 0 to 5
)

@Entity(tableName = "leaderboard")
data class LeaderboardEntry(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val uid: Long,
    val ign: String,
    val score: Int,
    val isFlagged: Boolean = false,
    val reportCount: Int = 0
)
