package com.example.data

import android.content.Context
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlin.random.Random

class GameRepository(private val db: AppDatabase) {
    val playerProfile: Flow<PlayerProfile?> = db.playerDao().getPlayerProfile()
    val topScores: Flow<List<LeaderboardEntry>> = db.leaderboardDao().getTopScores()

    suspend fun ensureProfileExists(): PlayerProfile {
        val existing = db.playerDao().getPlayerProfileSync()
        return if (existing != null) {
            existing
        } else {
            val randomUid = Random.nextLong(100000, 999999)
            val newProfile = PlayerProfile(
                uid = randomUid,
                ign = "Survivor_$randomUid",
                cash = 1000,
                highScore = 0
            )
            db.playerDao().insertPlayerProfile(newProfile)
            
            // Seed base leaderboard scores with realistic entries
            seedLeaderboard()
            
            newProfile
        }
    }

    suspend fun updateProfile(profile: PlayerProfile) {
        db.playerDao().updatePlayerProfile(profile)
    }

    private suspend fun seedLeaderboard() {
        // Realistic competitive entries
        val seeds = listOf(
            LeaderboardEntry(uid = 112233, ign = "Tactical_Viper", score = 24500),
            LeaderboardEntry(uid = 445566, ign = "Apex_Hunter", score = 18200),
            LeaderboardEntry(uid = 778899, ign = "ShadowSlayer", score = 12600),
            LeaderboardEntry(uid = 101112, ign = "FogNavigator", score = 9800),
            LeaderboardEntry(uid = 131415, ign = "ZomBuster", score = 6100),
            // Anomalous/Suspicious entries for reporting test
            LeaderboardEntry(uid = 999999, ign = "AimBotPro_Cheat", score = 999990, reportCount = 0),
            LeaderboardEntry(uid = 888888, ign = "ImmortalXP", score = 850000, reportCount = 0),
            LeaderboardEntry(uid = 777777, ign = "WallHaxGod", score = 550000, reportCount = 0)
        )
        for (item in seeds) {
            db.leaderboardDao().insertLeaderboardEntry(item)
        }
    }

    suspend fun submitScore(uid: Long, ign: String, score: Int) {
        val entry = LeaderboardEntry(uid = uid, ign = ign, score = score)
        db.leaderboardDao().insertLeaderboardEntry(entry)
        
        // Also update player's high score in profile
        val profile = db.playerDao().getPlayerProfileSync()
        if (profile != null && score > profile.highScore) {
            db.playerDao().updatePlayerProfile(profile.copy(highScore = score))
        }
    }

    suspend fun reportCheat(id: Int) {
        val entry = db.leaderboardDao().getEntryById(id)
        if (entry != null) {
            val updated = entry.copy(
                reportCount = entry.reportCount + 1,
                isFlagged = entry.reportCount >= 2 // Flag as confirmed cheat after multiple reports
            )
            // If flagged as confirmed cheat by our local secure anti-cheat, we can either flag or delete it
            if (updated.isFlagged) {
                // In an anti-cheat block, we flag it in the leaderboard UI as [BANNED/SUSPENDED] 
                // and notify database admin. Let's update it.
                db.leaderboardDao().updateLeaderboardEntry(updated)
            } else {
                db.leaderboardDao().updateLeaderboardEntry(updated)
            }
        }
    }

    suspend fun deleteLeaderboardEntry(id: Int) {
        db.leaderboardDao().deleteEntry(id)
    }
}
