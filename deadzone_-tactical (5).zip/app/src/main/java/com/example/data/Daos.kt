package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PlayerDao {
    @Query("SELECT * FROM player_profile LIMIT 1")
    fun getPlayerProfile(): Flow<PlayerProfile?>

    @Query("SELECT * FROM player_profile LIMIT 1")
    suspend fun getPlayerProfileSync(): PlayerProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlayerProfile(profile: PlayerProfile)

    @Update
    suspend fun updatePlayerProfile(profile: PlayerProfile)
}

@Dao
interface LeaderboardDao {
    @Query("SELECT * FROM leaderboard ORDER BY score DESC LIMIT 50")
    fun getTopScores(): Flow<List<LeaderboardEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLeaderboardEntry(entry: LeaderboardEntry)

    @Update
    suspend fun updateLeaderboardEntry(entry: LeaderboardEntry)

    @Query("SELECT * FROM leaderboard WHERE id = :id")
    suspend fun getEntryById(id: Int): LeaderboardEntry?

    @Query("DELETE FROM leaderboard WHERE id = :id")
    suspend fun deleteEntry(id: Int)
}
