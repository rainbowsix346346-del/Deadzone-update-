package com.example.ui

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.util.Log
import com.example.R

enum class SfxType {
    PISTOL, SHOTGUN, RIFLE, EXPLOSION, EXPLOSION_AFTERMATH,
    AIRSTRIKE_JET, ZOMBIE_GROWL, ZOMBIE_BOSS_GROWL, ZOMBIE_DEATH,
    FOOTSTEP, PLAYER_HURT, RELOAD, DOOR_OPEN, COIN, BUTTON_CLICK
}

class AudioManager(private val context: Context) {
    private var mediaPlayer: MediaPlayer? = null
    private var currentMusicResId: Int? = null

    private var soundPool: SoundPool? = null
    private val sfxMap = HashMap<SfxType, Int>()

    var musicVolume = 1.0f
        set(value) {
            field = value.coerceIn(0f, 1f)
            mediaPlayer?.setVolume(field, field)
        }

    var sfxVolume = 1.0f
        set(value) {
            field = value.coerceIn(0f, 1f)
        }

    init {
        try {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            
            soundPool = SoundPool.Builder()
                .setMaxStreams(10)
                .setAudioAttributes(attrs)
                .build()

            loadSfx(SfxType.PISTOL, R.raw.sfx_pistol)
            loadSfx(SfxType.SHOTGUN, R.raw.sfx_shotgun)
            loadSfx(SfxType.RIFLE, R.raw.sfx_rifle)
            loadSfx(SfxType.EXPLOSION, R.raw.sfx_explosion)
            loadSfx(SfxType.EXPLOSION_AFTERMATH, R.raw.sfx_explosion_aftermath)
            loadSfx(SfxType.AIRSTRIKE_JET, R.raw.sfx_airstrike_jet)
            loadSfx(SfxType.ZOMBIE_GROWL, R.raw.sfx_zombie_growl)
            loadSfx(SfxType.ZOMBIE_BOSS_GROWL, R.raw.sfx_zombie_boss_growl)
            loadSfx(SfxType.ZOMBIE_DEATH, R.raw.sfx_zombie_death)
            loadSfx(SfxType.FOOTSTEP, R.raw.sfx_footstep)
            loadSfx(SfxType.PLAYER_HURT, R.raw.sfx_player_hurt)
            loadSfx(SfxType.RELOAD, R.raw.sfx_reload)
            loadSfx(SfxType.DOOR_OPEN, R.raw.sfx_door_open)
            loadSfx(SfxType.COIN, R.raw.sfx_coin)
            loadSfx(SfxType.BUTTON_CLICK, R.raw.sfx_button_click)
        } catch (e: Exception) {
            Log.e("AudioManager", "Error during init", e)
        }
    }

    private fun loadSfx(type: SfxType, resId: Int) {
        soundPool?.let { pool ->
            try {
                val id = pool.load(context, resId, 1)
                sfxMap[type] = id
            } catch (e: Exception) {
                Log.e("AudioManager", "Failed to load SFX: $type", e)
            }
        }
    }

    fun playMusic(resId: Int) {
        if (currentMusicResId == resId && mediaPlayer?.isPlaying == true) {
            return
        }

        stopMusic()
        currentMusicResId = resId
        try {
            val player = MediaPlayer.create(context, resId)
            if (player != null) {
                mediaPlayer = player.apply {
                    isLooping = true
                    setVolume(musicVolume, musicVolume)
                    start()
                }
            } else {
                Log.e("AudioManager", "MediaPlayer.create returned null for resId: $resId")
            }
        } catch (e: Exception) {
            Log.e("AudioManager", "Error playing music: $resId", e)
        }
    }

    fun stopMusic() {
        try {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    it.stop()
                }
                it.release()
            }
        } catch (e: Exception) {
            Log.e("AudioManager", "Error stopping music", e)
        }
        mediaPlayer = null
        currentMusicResId = null
    }

    fun pauseMusic() {
        try {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    it.pause()
                }
            }
        } catch (e: Exception) {
            Log.e("AudioManager", "Error pausing music", e)
        }
    }

    fun resumeMusic() {
        try {
            mediaPlayer?.let {
                if (!it.isPlaying) {
                    it.start()
                }
            }
        } catch (e: Exception) {
            Log.e("AudioManager", "Error resuming music", e)
        }
    }

    fun playSfx(type: SfxType) {
        soundPool?.let { pool ->
            val soundId = sfxMap[type] ?: return
            try {
                pool.play(soundId, sfxVolume, sfxVolume, 1, 0, 1.0f)
            } catch (e: Exception) {
                Log.e("AudioManager", "Error playing SFX $type", e)
            }
        }
    }

    fun release() {
        stopMusic()
        try {
            soundPool?.release()
        } catch (e: Exception) {
            Log.e("AudioManager", "Error releasing soundpool", e)
        }
        soundPool = null
        sfxMap.clear()
    }
}

object SoundManager {
    private var instance: AudioManager? = null

    fun init(context: Context) {
        if (instance == null) {
            instance = AudioManager(context.applicationContext)
        }
    }

    fun playSfx(type: SfxType) {
        instance?.playSfx(type)
    }

    fun playMusic(resId: Int) {
        instance?.playMusic(resId)
    }

    fun stopMusic() {
        instance?.stopMusic()
    }

    fun pauseMusic() {
        instance?.pauseMusic()
    }

    fun resumeMusic() {
        instance?.resumeMusic()
    }

    fun setMusicVolume(vol: Float) {
        instance?.musicVolume = vol
    }

    fun setSfxVolume(vol: Float) {
        instance?.sfxVolume = vol
    }

    fun getMusicVolume(): Float = instance?.musicVolume ?: 1.0f

    fun getSfxVolume(): Float = instance?.sfxVolume ?: 1.0f
}
