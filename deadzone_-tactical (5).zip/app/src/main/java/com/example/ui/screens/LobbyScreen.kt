package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameLanguage
import com.example.data.Localization
import com.example.data.PlayerProfile
import com.example.ui.Screen
import com.example.ui.theme.DeadzoneAccent
import com.example.ui.theme.DeadzonePrimary
import com.example.ui.theme.DeadzoneSurface
import com.example.ui.theme.DeadzoneTertiary
import com.example.ui.SoundManager
import com.example.ui.SfxType

@Composable
fun LobbyScreen(
    profile: PlayerProfile?,
    language: GameLanguage,
    onBack: () -> Unit,
    onEquipSkin: (String) -> Unit,
    onBuySkin: (String, Int) -> Boolean,
    onUpgradeSkill: (String, Int) -> Boolean,
    onUpdateIgn: (String) -> Unit
) {
    var ignInput by remember { mutableStateOf("") }
    var isEditingIgn by remember { mutableStateOf(false) }
    var lobbyErrorMsg by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(profile) {
        if (profile != null && ignInput.isEmpty()) {
            ignInput = profile.ign
        }
    }

    Scaffold(
        topBar = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable {
                        SoundManager.playSfx(SfxType.BUTTON_CLICK)
                        onBack()
                    }.testTag("lobby_back_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Return to menu",
                        tint = DeadzonePrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "BACK",
                        color = DeadzonePrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                }

                Text(
                    text = Localization.get("lobby_title", language).uppercase(),
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 3.sp,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        },
        containerColor = Color.Black
    ) { paddingValues ->
        if (profile == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = DeadzonePrimary)
            }
        } else {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(16.dp)
            ) {
                // Left Column: Survivor Stats & IGN change
                Column(
                    modifier = Modifier
                        .weight(1.1f)
                        .fillMaxHeight()
                        .padding(end = 12.dp)
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DeadzoneSurface),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, DeadzonePrimary.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            // Header & IGN Edit
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (isEditingIgn) {
                                    OutlinedTextField(
                                        value = ignInput,
                                        onValueChange = { ignInput = it },
                                        singleLine = true,
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = DeadzonePrimary,
                                            unfocusedBorderColor = Color.Gray,
                                            focusedTextColor = Color.White,
                                            unfocusedTextColor = Color.White
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("ign_input_field")
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    IconButton(
                                        onClick = {
                                            if (ignInput.isNotBlank()) {
                                                onUpdateIgn(ignInput)
                                                isEditingIgn = false
                                            }
                                        },
                                        modifier = Modifier.testTag("save_ign_button")
                                    ) {
                                        Icon(Icons.Default.Check, "Save", tint = DeadzonePrimary)
                                    }
                                } else {
                                    Text(
                                        text = profile.ign,
                                        fontSize = 24.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DeadzonePrimary,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(
                                        onClick = { isEditingIgn = true },
                                        modifier = Modifier.testTag("edit_ign_button")
                                    ) {
                                        Icon(Icons.Default.Edit, "Edit Name", tint = Color.LightGray)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "SURVIVOR ID: #${profile.uid}",
                                fontSize = 11.sp,
                                color = Color.Gray,
                                letterSpacing = 2.sp
                            )

                            Divider(color = Color.DarkGray, modifier = Modifier.padding(vertical = 12.dp))

                            // Stats Grid
                            Text(
                                text = Localization.get("lobby_stats", language).uppercase(),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.LightGray,
                                letterSpacing = 1.sp
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            StatLine(Localization.get("lobby_games", language), profile.gamesPlayed.toString())
                            StatLine(Localization.get("lobby_kills", language), profile.totalKills.toString())
                            StatLine(Localization.get("lobby_highscore", language), "${profile.highScore} PTS")

                            Spacer(modifier = Modifier.height(16.dp))

                            // Cash display with glowing border
                            Surface(
                                color = DeadzonePrimary.copy(alpha = 0.08f),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, DeadzonePrimary.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        Localization.get("lobby_currency", language),
                                        fontSize = 12.sp,
                                        color = Color.White
                                    )
                                    Text(
                                        "$${profile.cash}",
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Black,
                                        color = DeadzonePrimary
                                    )
                                }
                            }
                        }
                    }

                    lobbyErrorMsg?.let { msg ->
                        Spacer(modifier = Modifier.height(8.dp))
                        Card(
                            colors = CardDefaults.cardColors(containerColor = DeadzoneTertiary.copy(alpha = 0.15f)),
                            modifier = Modifier.fillMaxWidth().border(1.dp, DeadzoneTertiary, RoundedCornerShape(4.dp))
                        ) {
                            Text(
                                text = msg,
                                color = DeadzoneTertiary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                        LaunchedEffect(msg) {
                            kotlinx.coroutines.delay(3000)
                            lobbyErrorMsg = null
                        }
                    }
                }

                // Right Column: Character customization & Skill Upgrades Tabbed/Scroll list
                Column(
                    modifier = Modifier
                        .weight(1.3f)
                        .fillMaxHeight()
                        .padding(start = 12.dp)
                ) {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // 1. Skill upgrades
                        item {
                            Text(
                                text = Localization.get("lobby_shop", language).uppercase(),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black,
                                color = DeadzoneAccent,
                                letterSpacing = 2.sp,
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                        }

                        // Fast Reload upgrade UI
                        item {
                            SkillUpgradeItem(
                                title = Localization.get("lobby_up_reload", language),
                                currentLevel = profile.reloadSkillLevel,
                                cost = profile.reloadSkillLevel * 200 + 300,
                                testTag = "upgrade_reload_btn",
                                onUpgrade = { cost ->
                                    val ok = onUpgradeSkill("reload", cost)
                                    if (ok) {
                                        SoundManager.playSfx(SfxType.COIN)
                                    } else {
                                        SoundManager.playSfx(SfxType.BUTTON_CLICK)
                                        lobbyErrorMsg = Localization.get("lobby_cash_low", language)
                                    }
                                }
                            )
                        }

                        // Silent footsteps upgrade UI
                        item {
                            SkillUpgradeItem(
                                title = Localization.get("lobby_up_stealth", language),
                                currentLevel = profile.stealthSkillLevel,
                                cost = profile.stealthSkillLevel * 200 + 300,
                                testTag = "upgrade_stealth_btn",
                                onUpgrade = { cost ->
                                    val ok = onUpgradeSkill("stealth", cost)
                                    if (ok) {
                                        SoundManager.playSfx(SfxType.COIN)
                                    } else {
                                        SoundManager.playSfx(SfxType.BUTTON_CLICK)
                                        lobbyErrorMsg = Localization.get("lobby_cash_low", language)
                                    }
                                }
                            )
                        }

                        // Battery lift capacity upgrade UI
                        item {
                            SkillUpgradeItem(
                                title = Localization.get("lobby_up_battery", language),
                                currentLevel = profile.batterySkillLevel,
                                cost = profile.batterySkillLevel * 200 + 300,
                                testTag = "upgrade_battery_btn",
                                onUpgrade = { cost ->
                                    val ok = onUpgradeSkill("battery", cost)
                                    if (ok) {
                                        SoundManager.playSfx(SfxType.COIN)
                                    } else {
                                        SoundManager.playSfx(SfxType.BUTTON_CLICK)
                                        lobbyErrorMsg = Localization.get("lobby_cash_low", language)
                                    }
                                }
                            )
                        }

                        // 2. Character Skin customizer
                        item {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = Localization.get("lobby_skins", language).uppercase(),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black,
                                color = DeadzonePrimary,
                                letterSpacing = 2.sp,
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                        }

                        val skins = listOf(
                            Pair("Stealth Recon", 0),
                            Pair("Cyber Commando", 500),
                            Pair("Hazmat Survivor", 500),
                            Pair("Neon Hunter", 500)
                        )

                        items(skins) { (skinName, cost) ->
                            val isUnlocked = profile.unlockedSkins.split(",").contains(skinName)
                            val isEquipped = profile.selectedSkin == skinName

                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isEquipped) DeadzonePrimary.copy(alpha = 0.08f) else DeadzoneSurface
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(
                                        width = 1.dp,
                                        color = if (isEquipped) DeadzonePrimary else Color.DarkGray,
                                        shape = RoundedCornerShape(6.dp)
                                    )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = skinName,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isEquipped) DeadzonePrimary else Color.White,
                                            fontSize = 14.sp
                                        )
                                        Text(
                                            text = when(skinName) {
                                                "Stealth Recon" -> "Passive: -15% noise generated during missions"
                                                "Cyber Commando" -> "Passive: +20% starting weapon firepower"
                                                "Hazmat Survivor" -> "Passive: +15% maximum health buffer"
                                                else -> "Passive: Flashlight capacity drains 30% slower"
                                            },
                                            fontSize = 11.sp,
                                            color = Color.LightGray
                                        )
                                    }

                                    Button(
                                        onClick = {
                                            if (isUnlocked) {
                                                SoundManager.playSfx(SfxType.BUTTON_CLICK)
                                                onEquipSkin(skinName)
                                            } else {
                                                val success = onBuySkin(skinName, cost)
                                                if (success) {
                                                    SoundManager.playSfx(SfxType.COIN)
                                                } else {
                                                    SoundManager.playSfx(SfxType.BUTTON_CLICK)
                                                    lobbyErrorMsg = Localization.get("lobby_cash_low", language)
                                                }
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isEquipped) Color.DarkGray else if (isUnlocked) DeadzoneAccent else DeadzonePrimary
                                        ),
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.testTag("skin_btn_${skinName.replace(" ", "_")}")
                                    ) {
                                        Text(
                                            text = if (isEquipped) "EQUIPPED" else if (isUnlocked) "EQUIP" else "$$cost",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isEquipped) Color.Gray else Color.Black
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatLine(label: String, valStr: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = Color.Gray, fontSize = 12.sp)
        Text(text = valStr, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

@Composable
fun SkillUpgradeItem(
    title: String,
    currentLevel: Int,
    cost: Int,
    testTag: String,
    onUpgrade: (Int) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DeadzoneSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color.DarkGray, RoundedCornerShape(6.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = "$title$currentLevel/5)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(modifier = Modifier.height(4.dp))
                Row {
                    for (i in 1..5) {
                        Box(
                            modifier = Modifier
                                .size(width = 16.dp, height = 6.dp)
                                .padding(end = 2.dp)
                                .background(if (i <= currentLevel) DeadzoneAccent else Color.DarkGray, RoundedCornerShape(1f))
                        )
                    }
                }
            }

            if (currentLevel >= 5) {
                Text(text = "MAXED", color = DeadzoneAccent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            } else {
                Button(
                    onClick = { onUpgrade(cost) },
                    colors = ButtonDefaults.buttonColors(containerColor = DeadzoneAccent),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.testTag(testTag)
                ) {
                    Text(text = "UPGRADE ($$cost)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                }
            }
        }
    }
}
