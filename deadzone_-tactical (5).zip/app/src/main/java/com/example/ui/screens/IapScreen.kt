package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameLanguage
import com.example.data.Localization
import com.example.ui.Screen
import com.example.ui.theme.DeadzoneAccent
import com.example.ui.theme.DeadzonePrimary
import com.example.ui.theme.DeadzoneSurface
import com.example.ui.theme.DeadzoneTertiary

data class StoreProduct(
    val id: String,
    val name: String,
    val coinsToReward: Int,
    val priceString: String,
    val description: String
)

@Composable
fun IapScreen(
    language: GameLanguage,
    onBack: () -> Unit,
    onPurchaseFinished: (Int) -> Unit
) {
    val products = listOf(
        StoreProduct("bundle_small", "Small Supply Bundle", 500, "$1.99", "Provides 500 in-game currency. Perfect for basic ammunition restocking and clearing a few gate barriers."),
        StoreProduct("bundle_med", "Tactical Support Air", 1500, "$4.99", "Provides 1500 in-game currency. Grants capability to acquire military weapon skins and reload passives!"),
        StoreProduct("bundle_large", "Biohazard Gold Chest", 5000, "$9.99", "Provides 5000 in-game currency. Maximize your tactical ability upgrades and immediately unlock all custom cosmetics!")
    )

    var purchasingProduct by remember { mutableStateOf<StoreProduct?>(null) }
    var successNotification by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { onBack() }.testTag("iap_back_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Return to menu",
                        tint = DeadzonePrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "BACK",
                        color = DeadzonePrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                }

                Text(
                    text = Localization.get("iap_title", language).uppercase(),
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 3.sp,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        },
        containerColor = Color.Black
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            Column {
                Text(
                    text = Localization.get("iap_subtitle", language).uppercase(),
                    color = DeadzoneAccent,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                // Layout grid
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(products) { prod ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = DeadzoneSurface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, DeadzonePrimary.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                        ) {
                            Column(
                                modifier = Modifier
                                    .padding(16.dp)
                                    .fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = prod.name,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "+${prod.coinsToReward} سکه",
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Black,
                                    color = DeadzonePrimary
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = prod.description,
                                    fontSize = 11.sp,
                                    color = Color.LightGray,
                                    modifier = Modifier.height(60.dp)
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Button(
                                    onClick = { purchasingProduct = prod },
                                    colors = ButtonDefaults.buttonColors(containerColor = DeadzoneAccent),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("buy_product_${prod.id}")
                                ) {
                                    Text(
                                        text = "${prod.priceString} USD",
                                        color = Color.Black,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    }
                }

                successNotification?.let { msg ->
                    Spacer(modifier = Modifier.height(16.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DeadzonePrimary.copy(alpha = 0.12f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, DeadzonePrimary, RoundedCornerShape(4.dp))
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Lock, "Protected", tint = DeadzonePrimary)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = msg,
                                color = DeadzonePrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    LaunchedEffect(msg) {
                        kotlinx.coroutines.delay(4000)
                        successNotification = null
                    }
                }
            }

            // Secure simulated payment pop-up dialog
            purchasingProduct?.let { prod ->
                AlertDialog(
                    onDismissRequest = { purchasingProduct = null },
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Lock, "Lock Secure", tint = DeadzoneAccent)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "SECURE SANDBOX TRANSCRIPT",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        }
                    },
                    text = {
                        Column {
                            Text(
                                text = "You are initiating a direct global billing gateway link for:",
                                fontSize = 12.sp,
                                color = Color.LightGray
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "${prod.name} (+${prod.coinsToReward} Coins)",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = DeadzonePrimary
                            )
                            Text(
                                text = "Price: ${prod.priceString}",
                                fontSize = 14.sp,
                                color = DeadzoneAccent,
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Security Status: 256-bit encrypted simulated environment, ready to authorize instantly without charging actual cards.",
                                fontSize = 10.sp,
                                color = Color.Gray
                            )
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                onPurchaseFinished(prod.coinsToReward)
                                successNotification = "PAYMENT AUTHORIZED! SECURE SYSTEM LOADED +${prod.coinsToReward} COINS SECURELY."
                                purchasingProduct = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DeadzonePrimary),
                            modifier = Modifier.testTag("confirm_checkout_button")
                        ) {
                            Text("AUTHORIZE PAYMENT", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    },
                    dismissButton = {
                        Button(
                            onClick = { purchasingProduct = null },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray)
                        ) {
                            Text("ABORT", color = Color.White, fontSize = 11.sp)
                        }
                    },
                    containerColor = DeadzoneSurface,
                    modifier = Modifier.border(1.dp, DeadzoneAccent, RoundedCornerShape(8.dp))
                )
            }
        }
    }
}
