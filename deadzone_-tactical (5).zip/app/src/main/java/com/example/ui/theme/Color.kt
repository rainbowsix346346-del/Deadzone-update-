package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

val DeadzonePrimary = Color(0xFF00FF66)
val DeadzoneSecondary = Color(0xFF333333)
val DeadzoneTertiary = Color(0xFFFF2244)
val DeadzoneBackground = Color(0xFF0A0F14)
val DeadzoneSurface = Color(0xFF131A21)
val DeadzoneAccent = Color(0xFF00D1FF)
