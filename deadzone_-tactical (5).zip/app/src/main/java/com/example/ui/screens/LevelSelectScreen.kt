package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.GameLanguage
import com.example.ui.Screen
import com.example.ui.theme.DeadzonePrimary
import com.example.ui.theme.DeadzoneSurface
import com.example.ui.SoundManager
import com.example.ui.SfxType

data class Level(
    val id: Int,
    val nameEn: String,
    val nameFa: String,
    val descriptionEn: String,
    val descriptionFa: String,
    val isUnlocked: Boolean
)

@Composable
fun LevelSelectScreen(
    language: GameLanguage,
    onBack: () -> Unit,
    onSelectLevel: (Int) -> Unit
) {
    val levels = listOf(
        Level(
            id = 1,
            nameEn = "Abandoned Research Lab",
            nameFa = "آزمایشگاه تحقیقاتی متروکه",
            descriptionEn = "Sector A-9. Hostile forces detected. Evacuate the main reactor zone.",
            descriptionFa = "بخش A-9. فعالیت زامبی‌ها در بالاترین سطح است. به سمت ژنراتور بروید.",
            isUnlocked = true
        ),
        Level(
            id = 2,
            nameEn = "Military Outpost Sector B",
            nameFa = "پایگاه نظامی بخش ب",
            descriptionEn = "Tanks overrun. Heavy ammunition stockpiles blocked by elite class undead.",
            descriptionFa = "مخازن تانک نابود شده است. انبار مهمات سنگین تحت کنترل زامبی‌های ارشد است.",
            isUnlocked = false
        ),
        Level(
            id = 3,
            nameEn = "City Center Quarantine Zone",
            nameFa = "منطقه قرنطینه مرکز شهر",
            descriptionEn = "High-rise barricades fell down. Infinite waves rushing from the metro doors.",
            descriptionFa = "موانع مرتفع شهری فروریخته است. گله‌های بی‌پایان زامبی از مترو هجوم می‌آورند.",
            isUnlocked = false
        ),
        Level(
            id = 4,
            nameEn = "Coastal Harbor Evacuation",
            nameFa = "بندرگاه ساحلی فرار نهایی",
            descriptionEn = "Last boat leaving in hours. Clear final roadblocks under nuclear haze.",
            descriptionFa = "آخرین کشتی نجات در حال خروج است. موانع پایانی را زیر غبار رادیواکتیو پاک کنید.",
            isUnlocked = false
        )
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("level_select_screen_container")
    ) {
        // Aesthetic Atmospheric background
        Image(
            painter = painterResource(id = R.drawable.img_zombie_splash),
            contentDescription = "Atmospheric Zombie Battle Zone",
            modifier = Modifier
                .fillMaxSize()
                .alpha(0.20f),
            contentScale = ContentScale.Crop
        )

        // Radial shadow vignette overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.95f)),
                        radius = 1200f
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
        ) {
            // Header Space with Back button & Title
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        SoundManager.playSfx(SfxType.BUTTON_CLICK)
                        onBack()
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .background(Color.DarkGray.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                        .border(1.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                        .testTag("level_select_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column {
                    Text(
                        text = if (language == GameLanguage.PERSIAN) "انتخاب مرحله بقا" else "SELECT TACTICAL ZONE",
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Black,
                        color = DeadzonePrimary,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = if (language == GameLanguage.PERSIAN) "منطقه عملیاتی خود را جهت نبرد انتخاب کنید" else "CHOOSE OUTPOST FOR DEPLOYMENT",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.6f),
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Separator glow line
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp)
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(DeadzonePrimary, Color.Transparent)
                        )
                    )
                    .padding(bottom = 16.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Scrollable Level List containing dataclass structured Levels
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(levels) { level ->
                    val isUnlocked = level.isUnlocked
                    val levelName = if (language == GameLanguage.PERSIAN) level.nameFa else level.nameEn
                    val levelDesc = if (language == GameLanguage.PERSIAN) level.descriptionFa else level.descriptionEn

                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isUnlocked) DeadzoneSurface.copy(alpha = 0.85f) else Color.DarkGray.copy(alpha = 0.25f)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = if (isUnlocked) 1.dp else 0.5.dp,
                                color = if (isUnlocked) DeadzonePrimary.copy(alpha = 0.4f) else Color.White.copy(alpha = 0.1f),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clip(RoundedCornerShape(12.dp))
                            .clickable(enabled = isUnlocked) {
                                SoundManager.playSfx(SfxType.BUTTON_CLICK)
                                onSelectLevel(level.id)
                            }
                            .testTag("level_card_${level.id}")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Map icon / decoration box
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .background(
                                        if (isUnlocked) DeadzonePrimary.copy(alpha = 0.15f) else Color.White.copy(alpha = 0.05f),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .border(
                                        1.dp,
                                        if (isUnlocked) DeadzonePrimary.copy(alpha = 0.3f) else Color.White.copy(alpha = 0.1f),
                                        RoundedCornerShape(8.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isUnlocked) {
                                    Icon(
                                        imageVector = Icons.Default.LocationOn,
                                        contentDescription = "Active Zone",
                                        tint = DeadzonePrimary,
                                        modifier = Modifier.size(28.dp)
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = "Locked Zone",
                                        tint = Color.Gray,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            // Name and desc
                            Column(
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = levelName,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isUnlocked) Color.White else Color.White.copy(alpha = 0.4f)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = levelDesc,
                                    fontSize = 11.sp,
                                    color = if (isUnlocked) Color.White.copy(alpha = 0.7f) else Color.White.copy(alpha = 0.3f),
                                    lineHeight = 15.sp
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            // Status badge
                            if (isUnlocked) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Play",
                                    tint = DeadzonePrimary,
                                    modifier = Modifier.size(24.dp)
                                )
                            } else {
                                Surface(
                                    color = Color.Black.copy(alpha = 0.4f),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.border(1.dp, Color.Gray.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                                ) {
                                    Text(
                                        text = if (language == GameLanguage.PERSIAN) "قفل" else "LOCKED",
                                        color = Color.Gray,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
