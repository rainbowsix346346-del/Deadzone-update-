package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameLanguage
import com.example.data.Localization
import com.example.ui.GameDifficulty
import com.example.ui.Screen
import com.example.ui.theme.DeadzoneAccent
import com.example.ui.theme.DeadzonePrimary
import com.example.ui.theme.DeadzoneSurface

import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import com.example.ui.SoundManager
import com.example.ui.SfxType

@Composable
fun SettingsScreen(
    currentLanguage: GameLanguage,
    currentDifficulty: GameDifficulty,
    currentSensitivity: Float,
    musicVolume: Float,
    sfxVolume: Float,
    onBack: () -> Unit,
    onLanguageChange: (GameLanguage) -> Unit,
    onDifficultyChange: (GameDifficulty) -> Unit,
    onSensitivityChange: (Float) -> Unit,
    onMusicVolumeChange: (Float) -> Unit,
    onSfxVolumeChange: (Float) -> Unit
) {
    Scaffold(
        topBar = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable {
                        SoundManager.playSfx(SfxType.BUTTON_CLICK)
                        onBack()
                    }.testTag("settings_back_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Return to menu",
                        tint = DeadzonePrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "BACK",
                        color = DeadzonePrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                }

                Text(
                    text = Localization.get("settings_title", currentLanguage).uppercase(),
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 3.sp,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        },
        containerColor = Color.Black
    ) { paddingValues ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            // Left half: General Settings (Difficulty, Sensitivity)
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .verticalScroll(rememberScrollState())
                    .padding(end = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Difficulty header
                Text(
                    text = Localization.get("settings_diff", currentLanguage).uppercase(),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = DeadzoneAccent,
                    letterSpacing = 2.sp
                )

                // Difficulty selectors
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    GameDifficulty.values().forEach { diff ->
                        val isSelected = currentDifficulty == diff
                        val labelKey = when (diff) {
                            GameDifficulty.EASY -> "diff_easy"
                            GameDifficulty.MEDIUM -> "diff_med"
                            GameDifficulty.HARD -> "diff_hard"
                            GameDifficulty.NIGHTMARE -> "diff_nightmare"
                        }

                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) DeadzonePrimary.copy(alpha = 0.08f) else DeadzoneSurface
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    SoundManager.playSfx(SfxType.BUTTON_CLICK)
                                    onDifficultyChange(diff)
                                }
                                .border(
                                    width = 1.dp,
                                    color = if (isSelected) DeadzonePrimary else Color.DarkGray,
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .testTag("diff_card_${diff.name}")
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { onDifficultyChange(diff) },
                                    colors = RadioButtonDefaults.colors(
                                        selectedColor = DeadzonePrimary,
                                        unselectedColor = Color.DarkGray
                                    )
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = Localization.get(labelKey, currentLanguage),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) DeadzonePrimary else Color.White
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Sensitivity selector
                Text(
                    text = Localization.get("settings_sens", currentLanguage).uppercase(),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = DeadzoneAccent,
                    letterSpacing = 2.sp
                )

                Card(
                    colors = CardDefaults.cardColors(containerColor = DeadzoneSurface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color.DarkGray, RoundedCornerShape(4.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                Localization.get("sens_low", currentLanguage),
                                fontSize = 10.sp,
                                color = Color.Gray
                            )
                            Text(
                                "x${"%.1f".format(currentSensitivity)}",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black,
                                color = DeadzoneAccent
                            )
                            Text(
                                Localization.get("sens_high", currentLanguage),
                                fontSize = 10.sp,
                                color = Color.Gray
                            )
                        }

                        Slider(
                            value = currentSensitivity,
                            onValueChange = onSensitivityChange,
                            valueRange = 0.5f..2.0f,
                            colors = SliderDefaults.colors(
                                thumbColor = DeadzoneAccent,
                                activeTrackColor = DeadzoneAccent,
                                inactiveTrackColor = Color.DarkGray
                            ),
                            modifier = Modifier.testTag("sens_slider")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // VOLUME CONTROLS section
                Text(
                    text = if (currentLanguage == GameLanguage.PERSIAN) "تنظیمات ولوم صدا" else "AUDIO HARDWARE CONFIG",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = DeadzoneAccent,
                    letterSpacing = 2.sp
                )

                Card(
                    colors = CardDefaults.cardColors(containerColor = DeadzoneSurface),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color.DarkGray, RoundedCornerShape(4.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // Music Slider label
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                Localization.get("settings_music_volume", currentLanguage),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                "${(musicVolume * 100).toInt()}%",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                color = DeadzoneAccent
                            )
                        }

                        Slider(
                            value = musicVolume,
                            onValueChange = onMusicVolumeChange,
                            valueRange = 0f..1f,
                            colors = SliderDefaults.colors(
                                thumbColor = DeadzoneAccent,
                                activeTrackColor = DeadzoneAccent,
                                inactiveTrackColor = Color.DarkGray
                            ),
                            modifier = Modifier.testTag("music_volume_slider")
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // SFX Slider label
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                Localization.get("settings_sfx_volume", currentLanguage),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                "${(sfxVolume * 100).toInt()}%",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                color = DeadzoneAccent
                            )
                        }

                        Slider(
                            value = sfxVolume,
                            onValueChange = onSfxVolumeChange,
                            valueRange = 0f..1f,
                            colors = SliderDefaults.colors(
                                thumbColor = DeadzoneAccent,
                                activeTrackColor = DeadzoneAccent,
                                inactiveTrackColor = Color.DarkGray
                            ),
                            modifier = Modifier.testTag("sfx_volume_slider")
                        )
                    }
                }
            }

            // Right half: Language Selection
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .padding(start = 12.dp)
            ) {
                Text(
                    text = Localization.get("settings_lang", currentLanguage).uppercase(),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = DeadzonePrimary,
                    letterSpacing = 2.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .border(1.dp, Color.DarkGray, RoundedCornerShape(6.dp))
                        .background(DeadzoneSurface)
                        .padding(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(GameLanguage.values()) { lang ->
                        val isSelected = currentLanguage == lang

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    SoundManager.playSfx(SfxType.BUTTON_CLICK)
                                    onLanguageChange(lang)
                                }
                                .background(
                                    if (isSelected) DeadzonePrimary.copy(alpha = 0.1f) else Color.Transparent,
                                    RoundedCornerShape(4.dp)
                                )
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                                .testTag("lang_row_${lang.name}"),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = lang.displayName,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) DeadzonePrimary else Color.White
                            )

                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Selected lang",
                                    tint = DeadzonePrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
